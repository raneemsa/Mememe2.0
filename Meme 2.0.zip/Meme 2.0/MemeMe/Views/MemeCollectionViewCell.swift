//
//  MemeCollectionViewCell.swift
//  MemeMe
//
//  Created by Raneem on 4/22/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var memeImage: UIImageView!
    
}
